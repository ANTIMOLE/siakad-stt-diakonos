-- AlterTable
ALTER TABLE "users" ADD COLUMN     "username" TEXT;
