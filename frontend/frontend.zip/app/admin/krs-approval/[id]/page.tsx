'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { CheckCircle, XCircle, AlertTriangle, ArrowLeft } from 'lucide-react';

import PageHeader from '@/components/shared/PageHeader';
import LoadingSpinner from '@/components/shared/LoadingSpinner';
import ErrorState from '@/components/shared/ErrorState';
import StatusBadge from '@/components/features/status/StatusBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { toast } from 'sonner';

import { krsAPI } from '@/lib/api';
import { KRS } from '@/types/model';

export default function DetailKRSApprovalPage() {
  const params = useParams();
  const router = useRouter();
  const krsId = parseInt(params.id as string);

  // ============================================
  // STATE MANAGEMENT
  // ============================================
  const [krs, setKrs] = useState<KRS | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [catatan, setCatatan] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // ============================================
  // FETCH KRS DATA
  // ============================================
  useEffect(() => {
    const fetchKRS = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const response = await krsAPI.getById(krsId);

        // ✅ response SUDAH auto-unwrapped
        if (response.success) {
          setKrs(response.data || null);
          // Pre-fill catatan jika ada
          if (response.data?.catatanAdmin) {
            setCatatan(response.data.catatanAdmin);
          }
        } else {
          setError(response.message || 'Gagal memuat data KRS');
        }
      } catch (err: any) {
        console.error('Fetch KRS error:', err);
        setError(
          err.response?.data?.message ||
          err.message ||
          'Terjadi kesalahan saat memuat data KRS'
        );
      } finally {
        setIsLoading(false);
      }
    };

    if (krsId) {
      fetchKRS();
    }
  }, [krsId]);

  // ============================================
  // VALIDATION
  // ============================================
  const validateKRS = () => {
    if (!krs) return { batasSKS: false, konflikJadwal: false };

    // Validasi batas SKS (max 24)
    const batasSKS = krs.totalSKS <= 24;

    // TODO: Implementasi validasi konflik jadwal di backend
    // Untuk sementara assume tidak ada konflik
    const konflikJadwal = false;

    return { batasSKS, konflikJadwal };
  };

  const validasi = validateKRS();
  const hasIssues = !validasi.batasSKS || validasi.konflikJadwal;

  // ============================================
  // HANDLERS
  // ============================================
  const handleApprove = async () => {
    if (!krs) return;

    try {
      setIsProcessing(true);

      const response = await krsAPI.approve(krs.id, catatan || undefined);

      // ✅ response SUDAH auto-unwrapped
      if (response.success) {
        toast.success('KRS berhasil disetujui');
        router.push('/admin/krs-approval');
      } else {
        toast.error(response.message || 'Gagal menyetujui KRS');
      }
    } catch (err: any) {
      console.error('Approve error:', err);
      toast.error(
        err.response?.data?.message ||
        err.message ||
        'Terjadi kesalahan saat menyetujui KRS'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!krs) return;

    if (!catatan.trim()) {
      toast.error('Catatan wajib diisi saat menolak KRS');
      return;
    }

    try {
      setIsProcessing(true);

      const response = await krsAPI.reject(krs.id, catatan);

      // ✅ response SUDAH auto-unwrapped
      if (response.success) {
        toast.success('KRS berhasil ditolak');
        router.push('/admin/krs-approval');
      } else {
        toast.error(response.message || 'Gagal menolak KRS');
      }
    } catch (err: any) {
      console.error('Reject error:', err);
      toast.error(
        err.response?.data?.message ||
        err.message ||
        'Terjadi kesalahan saat menolak KRS'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRetry = () => {
    window.location.reload();
  };

  // ============================================
  // LOADING STATE
  // ============================================
  if (isLoading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <LoadingSpinner size="lg" text="Memuat data KRS..." />
      </div>
    );
  }

  // ============================================
  // ERROR STATE
  // ============================================
  if (error || !krs) {
    return (
      <ErrorState
        title="Gagal Memuat Data"
        message={error || 'KRS tidak ditemukan'}
        onRetry={handleRetry}
      />
    );
  }

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <PageHeader
          title="Review KRS"
          description={`${krs.mahasiswa?.namaLengkap || '-'} (${krs.mahasiswa?.nim || '-'})`}
          breadcrumbs={[
            { label: 'Dashboard', href: '/admin/dashboard' },
            { label: 'Approval KRS', href: '/admin/krs-approval' },
            { label: 'Review' },
          ]}
        />
        <Button variant="outline" onClick={() => router.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Kembali
        </Button>
      </div>

      {/* Status Badge */}
      {krs.status !== 'SUBMITTED' && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Informasi</AlertTitle>
          <AlertDescription>
            KRS ini berstatus <StatusBadge status={krs.status} className="ml-1" />. 
            {krs.status === 'APPROVED' && ' KRS sudah disetujui sebelumnya.'}
            {krs.status === 'REJECTED' && ' KRS sudah ditolak sebelumnya.'}
            {krs.status === 'DRAFT' && ' KRS masih dalam status draft.'}
          </AlertDescription>
        </Alert>
      )}

      {/* Mahasiswa Info */}
      <Card>
        <CardHeader>
          <CardTitle>Data Mahasiswa</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">NIM</p>
              <p className="font-mono font-medium">{krs.mahasiswa?.nim || '-'}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Program Studi</p>
              {krs.mahasiswa?.prodi ? (
                <Badge>{krs.mahasiswa.prodi.kode}</Badge>
              ) : (
                <span className="text-sm">-</span>
              )}
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Angkatan</p>
              <p className="font-medium">{krs.mahasiswa?.angkatan || '-'}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Semester</p>
              {krs.semester ? (
                <p className="text-sm">
                  {krs.semester.tahunAkademik} {krs.semester.periode}
                </p>
              ) : (
                <span className="text-sm">-</span>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Validasi Status */}
      <Card>
        <CardHeader>
          <CardTitle>Hasil Validasi</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-lg border">
            <span className="text-sm font-medium">Konflik Jadwal</span>
            {validasi.konflikJadwal ? (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                <AlertTriangle className="mr-1 h-3 w-3" />
                Ada Konflik
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <CheckCircle className="mr-1 h-3 w-3" />
                Tidak Ada
              </Badge>
            )}
          </div>

          <div className="flex items-center justify-between p-3 rounded-lg border">
            <span className="text-sm font-medium">Batas SKS (Max 24)</span>
            {validasi.batasSKS ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <CheckCircle className="mr-1 h-3 w-3" />
                {krs.totalSKS} SKS
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                <XCircle className="mr-1 h-3 w-3" />
                {krs.totalSKS} SKS (Melebihi)
              </Badge>
            )}
          </div>

          {hasIssues && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Perhatian</AlertTitle>
              <AlertDescription>
                KRS memiliki masalah validasi. Periksa kembali sebelum approve.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Mata Kuliah */}
      <Card>
        <CardHeader>
          <CardTitle>
            Mata Kuliah yang Diambil
            <span className="ml-2 text-sm font-normal text-muted-foreground">
              (Total: {krs.totalSKS} SKS)
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {krs.detail && krs.detail.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kode MK</TableHead>
                  <TableHead>Nama Mata Kuliah</TableHead>
                  <TableHead className="text-center">SKS</TableHead>
                  <TableHead>Dosen</TableHead>
                  <TableHead>Jadwal</TableHead>
                  <TableHead>Ruangan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {krs.detail.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-mono">
                      {item.kelasMK?.mataKuliah?.kodeMK || '-'}
                    </TableCell>
                    <TableCell>{item.kelasMK?.mataKuliah?.namaMK || '-'}</TableCell>
                    <TableCell className="text-center">
                      <Badge variant="outline">{item.kelasMK?.mataKuliah?.sks || 0}</Badge>
                    </TableCell>
                    <TableCell>{item.kelasMK?.dosen?.namaLengkap || '-'}</TableCell>
                    <TableCell>
                      {item.kelasMK?.hari} {item.kelasMK?.jamMulai}-{item.kelasMK?.jamSelesai}
                    </TableCell>
                    <TableCell>{item.kelasMK?.ruangan?.nama || '-'}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              Tidak ada mata kuliah yang diambil
            </p>
          )}
        </CardContent>
      </Card>

      {/* Catatan & Actions */}
      {krs.status === 'SUBMITTED' && (
        <Card>
          <CardHeader>
            <CardTitle>Catatan Admin</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="catatan">
                Catatan untuk mahasiswa (Wajib untuk reject)
              </Label>
              <Textarea
                id="catatan"
                rows={4}
                placeholder="Contoh: KRS sudah sesuai dengan kurikulum semester 5"
                value={catatan}
                onChange={(e) => setCatatan(e.target.value)}
                className="mt-2"
                disabled={isProcessing}
              />
            </div>

            <div className="flex gap-3">
              <Button
                className="flex-1"
                onClick={handleApprove}
                disabled={isProcessing}
              >
                <CheckCircle className="mr-2 h-4 w-4" />
                {isProcessing ? 'Memproses...' : 'Setujui KRS'}
              </Button>
              <Button
                variant="destructive"
                className="flex-1"
                onClick={handleReject}
                disabled={isProcessing}
              >
                <XCircle className="mr-2 h-4 w-4" />
                {isProcessing ? 'Memproses...' : 'Tolak KRS'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Show existing catatan if already approved/rejected */}
      {krs.status !== 'SUBMITTED' && krs.catatanAdmin && (
        <Card>
          <CardHeader>
            <CardTitle>Catatan Admin</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm whitespace-pre-wrap">{krs.catatanAdmin}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
