'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Eye, FileText } from 'lucide-react';

import PageHeader from '@/components/shared/PageHeader';
import SearchBar from '@/components/shared/SearchBar';
import LoadingSpinner from '@/components/shared/LoadingSpinner';
import EmptyState from '@/components/shared/EmptyState';
import ErrorState from '@/components/shared/ErrorState';
import StatusBadge from '@/components/features/status/StatusBadge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatDate } from '@/lib/utils';
import { toast } from 'sonner';

import { krsAPI } from '@/lib/api';
import { KRS } from '@/types/model';

export default function KRSApprovalPage() {
  const router = useRouter();

  // ============================================
  // STATE MANAGEMENT
  // ============================================
  const [krsList, setKrsList] = useState<KRS[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);

  // Stats
  const [stats, setStats] = useState({
    pending: 0,
    approvedToday: 0,
    rejectedToday: 0,
  });

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('SUBMITTED');
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState<number>(10);

  // ============================================
  // FETCH KRS DATA
  // ============================================
  const fetchKRS = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Build clean filters
      const params: any = {
        page,
        limit,
      };

      // Only add filters if they have values
      if (statusFilter && statusFilter !== 'all') {
        params.status = statusFilter;
      }

      if (search && search.trim() !== '') {
        params.search = search.trim();
      }

      console.log('Fetching KRS with params:', params);

      const response = await krsAPI.getAll(params as any);

      if (response.success) {
        setKrsList(response.data || []);
        
        // Handle pagination
        const paginationData = (response as any).pagination;
        if (paginationData) {
          setTotalPages(paginationData.totalPages || 1);
          setTotalItems(paginationData.total || 0);
        } else {
          setTotalPages(1);
          setTotalItems(response.data?.length || 0);
        }
      } else {
        setError(response.message || 'Gagal memuat data KRS');
        toast.error(response.message || 'Gagal memuat data KRS');
      }
    } catch (err: any) {
      console.error('Fetch KRS error:', err);
      console.error('Error response:', err.response?.data);
      
      const errorMessage = err.response?.data?.message || err.message || 'Terjadi kesalahan saat memuat data KRS';
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [page, limit, statusFilter, search]);

  // Fetch stats
  const fetchStats = useCallback(async () => {
    try {
      // Get pending count
      const pendingResponse = await krsAPI.getAll({ 
        status: 'SUBMITTED',
      } as any);
      
      const paginationData = (pendingResponse as any).pagination;
      
      setStats({
        pending: paginationData?.total || 0,
        approvedToday: 0, // TODO: Backend support needed
        rejectedToday: 0, // TODO: Backend support needed
      });
    } catch (err) {
      console.error('Fetch stats error:', err);
      // Don't break the page if stats fail
      setStats({
        pending: 0,
        approvedToday: 0,
        rejectedToday: 0,
      });
    }
  }, []);

  useEffect(() => {
    fetchKRS();
  }, [fetchKRS]);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // ============================================
  // HANDLERS
  // ============================================
  const handleSearch = useCallback((query: string) => {
    setSearch(query);
    setPage(1); // Reset to first page
  }, []);

  const handleStatusChange = (value: string) => {
    setStatusFilter(value);
    setPage(1);
  };

  const handleLimitChange = (value: string) => {
    setLimit(parseInt(value));
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleView = (id: number) => {
    router.push(`/admin/krs-approval/${id}`);
  };

  const handleRetry = () => {
    fetchKRS();
    fetchStats();
  };

  // ============================================
  // LOADING STATE
  // ============================================
  if (isLoading && krsList.length === 0) {
    return (
      <div className="flex h-96 items-center justify-center">
        <LoadingSpinner size="lg" text="Memuat data KRS..." />
      </div>
    );
  }

  // ============================================
  // ERROR STATE
  // ============================================
  if (error && krsList.length === 0) {
    return (
      <ErrorState
        title="Gagal Memuat Data"
        message={error}
        onRetry={handleRetry}
      />
    );
  }

  // ============================================
  // RENDER
  // ============================================
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <PageHeader
        title="Approval KRS"
        description="Setujui atau tolak KRS mahasiswa"
        breadcrumbs={[
          { label: 'Dashboard', href: '/admin/dashboard' },
          { label: 'Approval KRS' },
        ]}
      />

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-yellow-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Menunggu Approval</p>
                <div className="text-3xl font-bold text-yellow-600">{stats.pending}</div>
              </div>
              <div className="rounded-full bg-yellow-100 p-3">
                <FileText className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-green-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Disetujui Hari Ini</p>
                <div className="text-3xl font-bold text-green-600">{stats.approvedToday}</div>
              </div>
              <div className="rounded-full bg-green-100 p-3">
                <FileText className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-red-200">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Ditolak Hari Ini</p>
                <div className="text-3xl font-bold text-red-600">{stats.rejectedToday}</div>
              </div>
              <div className="rounded-full bg-red-100 p-3">
                <FileText className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center">
            {/* Search */}
            <div className="flex-1">
              <SearchBar
                placeholder="Cari NIM atau Nama Mahasiswa..."
                onSearch={handleSearch}
                defaultValue={search}
              />
            </div>

            {/* Filter Status */}
            <Select
              value={statusFilter}
              onValueChange={handleStatusChange}
            >
              <SelectTrigger className="w-full md:w-44">
                <SelectValue placeholder="Filter Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="DRAFT">Draft</SelectItem>
                <SelectItem value="SUBMITTED">Menunggu Approval</SelectItem>
                <SelectItem value="APPROVED">Disetujui</SelectItem>
                <SelectItem value="REJECTED">Ditolak</SelectItem>
              </SelectContent>
            </Select>

            {/* Items per page */}
            <Select
              value={limit.toString()}
              onValueChange={handleLimitChange}
            >
              <SelectTrigger className="w-full md:w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 / hal</SelectItem>
                <SelectItem value="25">25 / hal</SelectItem>
                <SelectItem value="50">50 / hal</SelectItem>
                <SelectItem value="100">100 / hal</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>
              Daftar KRS
              {totalItems > 0 && (
                <span className="ml-2 text-sm font-normal text-muted-foreground">
                  ({totalItems} total)
                </span>
              )}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {krsList.length === 0 ? (
            <EmptyState
              icon={FileText}
              title={search ? 'Tidak Ditemukan' : 'Tidak Ada KRS'}
              description={
                search
                  ? `Tidak ada KRS yang cocok dengan pencarian "${search}"`
                  : statusFilter && statusFilter !== 'all'
                  ? `Tidak ada KRS dengan status ${statusFilter}`
                  : 'Belum ada KRS yang perlu di-review'
              }
              className="my-12 border-0"
            />
          ) : (
            <>
              {/* Table */}
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">No</TableHead>
                      <TableHead>NIM</TableHead>
                      <TableHead>Nama Mahasiswa</TableHead>
                      <TableHead>Prodi</TableHead>
                      <TableHead className="text-center">Semester</TableHead>
                      <TableHead className="text-center">Total SKS</TableHead>
                      <TableHead>Tanggal Submit</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-right">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {krsList.map((krs, index) => (
                      <TableRow key={krs.id}>
                        <TableCell className="font-medium text-muted-foreground">
                          {(page - 1) * limit + index + 1}
                        </TableCell>
                        <TableCell className="font-mono font-medium">
                          {krs.mahasiswa?.nim || '-'}
                        </TableCell>
                        <TableCell className="font-medium">
                          {krs.mahasiswa?.namaLengkap || '-'}
                        </TableCell>
                        <TableCell>
                          {krs.mahasiswa?.prodi ? (
                            <Badge variant="outline" className="font-normal">
                              {krs.mahasiswa.prodi.kode}
                            </Badge>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          {krs.semester ? (
                            <div className="text-sm">
                              <div className="font-medium">{krs.semester.tahunAkademik}</div>
                              <div className="text-muted-foreground">{krs.semester.periode}</div>
                            </div>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge variant="secondary" className="font-bold">
                            {krs.totalSKS}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          {krs.tanggalSubmit ? (
                            <div className="text-muted-foreground">
                              {formatDate(krs.tanggalSubmit)}
                            </div>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <StatusBadge status={krs.status} showIcon />
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant={krs.status === 'SUBMITTED' ? 'default' : 'outline'}
                            onClick={() => handleView(krs.id)}
                          >
                            <Eye className="mr-2 h-4 w-4" />
                            {krs.status === 'SUBMITTED' ? 'Review' : 'Detail'}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between border-t px-6 py-4">
                  <div className="text-sm text-muted-foreground">
                    Menampilkan <span className="font-medium">{(page - 1) * limit + 1}</span> -{' '}
                    <span className="font-medium">
                      {Math.min(page * limit, totalItems)}
                    </span>{' '}
                    dari <span className="font-medium">{totalItems}</span> data
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePageChange(page - 1)}
                      disabled={page === 1}
                    >
                      Sebelumnya
                    </Button>
                    
                    {/* Page numbers */}
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        let pageNum;
                        if (totalPages <= 5) {
                          pageNum = i + 1;
                        } else if (page <= 3) {
                          pageNum = i + 1;
                        } else if (page >= totalPages - 2) {
                          pageNum = totalPages - 4 + i;
                        } else {
                          pageNum = page - 2 + i;
                        }
                        
                        return (
                          <Button
                            key={pageNum}
                            variant={page === pageNum ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => handlePageChange(pageNum)}
                            className="w-10"
                          >
                            {pageNum}
                          </Button>
                        );
                      })}
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handlePageChange(page + 1)}
                      disabled={page === totalPages}
                    >
                      Selanjutnya
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
